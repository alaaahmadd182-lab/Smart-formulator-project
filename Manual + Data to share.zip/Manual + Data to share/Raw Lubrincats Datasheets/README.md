# Raw lubricant materials sheets

Documents collected from the Tree Trading Technical Documents library and classified by raw-material type and supplier.

## Contents

- `Base oils`: 248 documents in 15 supplier folders.
- `Additive packages`: 109 CI-4, CK-4, and CF-4 documents in 16 supplier folders.
- `Additive components`: 2 VM/VII documents in the Richful Lube Additive folder.

All available matching TDS, PDS, CPD, MSDS, and SDS revisions that had already been downloaded are retained. Image-format technical sheets are retained alongside PDFs.

`Additive packages/package_company_mapping.csv` records each package file's API category and supplier.

